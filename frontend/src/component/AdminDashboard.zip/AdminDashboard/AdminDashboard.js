import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip,
  PieChart, Pie, Cell,
  LineChart, Line, CartesianGrid,
} from 'recharts';
import '../styles/AdminDashboard.css';

const AdminDashboard = () => {
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth() + 1);
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
  const [stats, setStats] = useState({
    totalOrders: 0,
    totalEarnings: 0,
    totalPurchases: 0,
    completedOrders: 0,
    cancelledOrders: 0,
  });
  const [feedback, setFeedback] = useState([]);
  const COLORS = ['purple', 'green', 'red'];

  useEffect(() => {
    fetchStats();
    fetchFeedback();
  }, [currentMonth, currentYear]);

  const fetchStats = async () => {
    const res = await axios.get(`http://localhost:5000/api/earnings/${currentMonth}/${currentYear}`);
    setStats(res.data);
  };

  const fetchFeedback = async () => {
    const res = await axios.get('http://localhost:5000/api/feedback');
    setFeedback(res.data);
  };

  const handleNextMonth = () => {
    let nextMonth = currentMonth + 1;
    let year = currentYear;
    if (nextMonth > 12) {
      nextMonth = 1;
      year += 1;
    }
    setCurrentMonth(nextMonth);
    setCurrentYear(year);
  };

  const handlePrevMonth = () => {
    let prevMonth = currentMonth - 1;
    let year = currentYear;
    if (prevMonth < 1) {
      prevMonth = 12;
      year -= 1;
    }
    setCurrentMonth(prevMonth);
    setCurrentYear(year);
  };

  return (
    <div className="dashboard">
      <h1>Admin Dashboard</h1>

      <div className="dashboard-cards">
        <div className="card">
          <h3>Number of Orders</h3>
          <p>{stats.totalOrders}</p>
        </div>
        <div className="card">
          <h3>Total Purchases</h3>
          <p>${stats.totalPurchases}</p>
        </div>
        <div className="card">
          <h3>Total Cost</h3>
          <p>${stats.totalEarnings}</p>
        </div>
        <div className="card">
          <h3>Orders This Month</h3>
          <p>{stats.totalOrders}</p>
        </div>
      </div>

      <div className="dashboard-charts">
        <div className="card">
          <h3>Monthly Earnings</h3>
          <button onClick={handlePrevMonth}>&lt; Previous</button>
          <button onClick={handleNextMonth}>Next &gt;</button>
          <BarChart width={300} height={200} data={[{ name: 'Earnings', value: stats.totalEarnings }]}>
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="value" fill="#8884d8" />
          </BarChart>
        </div>
        <div className="card">
          <h3>Income Distribution</h3>
          <PieChart width={300} height={200}>
            <Pie
              dataKey="value"
              data={[
                { name: 'Earnings', value: stats.totalEarnings },
                { name: 'Purchases', value: stats.totalPurchases },
              ]}
              cx="50%"
              cy="50%"
              outerRadius={80}
              label
            >
              <Cell fill="blue" />
              <Cell fill="orange" />
            </Pie>
          </PieChart>
        </div>
        <div className="card">
          <h3>Orders Status</h3>
          <PieChart width={300} height={200}>
            <Pie
              dataKey="value"
              data={[
                { name: 'Pending', value: stats.totalOrders - stats.completedOrders - stats.cancelledOrders },
                { name: 'Completed', value: stats.completedOrders },
                { name: 'Cancelled', value: stats.cancelledOrders },
              ]}
              cx="50%"
              cy="50%"
              outerRadius={80}
              label
            >
              {COLORS.map((color, index) => (
                <Cell key={`cell-${index}`} fill={color} />
              ))}
            </Pie>
          </PieChart>
        </div>
        <div className="card">
          <h3>Feedback</h3>
          <LineChart width={300} height={200} data={feedback}>
            <XAxis dataKey="name" />
            <YAxis />
            <CartesianGrid stroke="#ccc" />
            <Line type="monotone" dataKey="value" stroke="#8884d8" />
          </LineChart>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
