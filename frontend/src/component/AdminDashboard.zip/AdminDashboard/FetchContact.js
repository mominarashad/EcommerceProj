import React, { useEffect, useState } from "react";
import axios from "axios";
import "../styles/ContactPage.css";
import { FaEnvelope, FaUser, FaTag, FaClock, FaReply } from "react-icons/fa";

const ContactPage = () => {
  const [contacts, setContacts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [responses, setResponses] = useState({});

  useEffect(() => {
    // Fetch data from the backend
    axios
      .get("http://localhost:5000/admin-contact")
      .then((response) => {
        setContacts(response.data);
        setLoading(false);
      })
      .catch((error) => {
        setError("Failed to fetch contact messages.");
        setLoading(false);
      });
  }, []);

  const handleResponseChange = (e, id) => {
    setResponses({ ...responses, [id]: e.target.value });
  };

  const handleSendResponse = (contactId) => {
    const responseMessage = responses[contactId];
    if (!responseMessage) return;

    axios
      .post(`http://localhost:5000/admin-contact/respond/${contactId}`, {
        response: responseMessage,
      })
      .then(() => {
        alert("Response sent successfully!");
        setResponses({ ...responses, [contactId]: "" });
      })
      .catch((error) => {
        alert("Failed to send the response. Please try again.");
        console.error(error);
      });
  };

  return (
    <div className="contact-page" style={styles.pageContainer}>
      <h1 style={styles.heading}>
        <FaReply style={styles.icon} /> Contact Messages
      </h1>
      {loading ? (
        <p>Loading messages...</p>
      ) : error ? (
        <p style={styles.error}>{error}</p>
      ) : contacts.length > 0 ? (
        <table style={styles.table}>
          <thead>
            <tr>
              <th>
                <FaUser style={styles.icon} />
              </th>
              <th>
                <FaEnvelope style={styles.icon} /> Email
              </th>
              <th>
                <FaTag style={styles.icon} /> Subject
              </th>
              <th>Message</th>
              <th>
                <FaClock style={styles.icon} /> Created At
              </th>
              <th>Admin Response</th>
            </tr>
          </thead>
          <tbody>
            {contacts.map((contact) => (
              <tr key={contact.id}>
                <td>{contact.name}</td>
                <td>{contact.email}</td>
                <td>{contact.subject}</td>
                <td>{contact.message}</td>
                <td>{new Date(contact.created_at).toLocaleString()}</td>
                <td>
                  <textarea
                    placeholder="Write a response..."
                    value={responses[contact.id] || ""}
                    onChange={(e) => handleResponseChange(e, contact.id)}
                    style={styles.textarea}
                  ></textarea>
                  <button
                    onClick={() => handleSendResponse(contact.id)}
                    style={styles.button}
                  >
                    <FaReply style={styles.buttonIcon} /> Send Response
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>No contact messages found.</p>
      )}
    </div>
  );
};

const styles = {
  pageContainer: {
    maxWidth: "100%",
    margin: "0 auto",
    padding: "20px",
    backgroundColor: "#f7f7f7",
    borderRadius: "8px",
    boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
  },
  heading: {
    textAlign: "center",
    marginBottom: "20px",
    fontSize: "28px",
    color: "#333",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "10px",
  },
  icon: {
    color: "grey",
  },
  table: {
    width: "100%",
    borderCollapse: "collapse",
    marginTop: "20px",
    backgroundColor: "#fff",
    boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
    borderRadius: "8px",
    overflow: "hidden",
  },
  textarea: {
    width: "80%",
    minHeight: "60px",
    margin: "10px 0",
    padding: "10px",
    borderRadius: "4px",
    border: "1px solid #ccc",
  },
  button: {
    padding: "8px 12px",
    backgroundColor: "#007BFF",
    color: "#fff",
    border: "none",
    borderRadius: "4px",
    cursor: "pointer",
    transition: "background-color 0.3s",
    display: "flex",
    alignItems: "center",
    gap: "5px",
  },
  buttonIcon: {
    marginRight: "5px",
  },
  error: {
    color: "red",
    textAlign: "center",
  },
};

export default ContactPage;
