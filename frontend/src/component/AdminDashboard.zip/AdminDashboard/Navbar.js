// components/Navbar.jsx
import React from "react";
import "../styles/Navbar.css";

const Navbar = () => {
  return (
    <div className="navbar">
      <h2 className="username">Hadia</h2>
      <img src="profile.png" alt="Profile" className="profile-img" />
    </div>
  );
};

export default Navbar;
