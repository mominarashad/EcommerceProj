import React from 'react'

function UserDashboard() {
  return (
    <div>
      hello i am user dashboard
    </div>
  )
}

export default UserDashboard
