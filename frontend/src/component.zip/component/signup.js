import React, { useState } from 'react';
import { Container, Row, Col, Alert, Button, Form } from 'react-bootstrap';
import { Link } from 'react-router-dom';

// Custom Signup Component
function SignUp() {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
  });
  const [isSuccess, setIsSuccess] = useState(false);
  const [message, setMessage] = useState('');

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('http://localhost:5000/api/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        const data = await response.json();
        console.log('Signup successful:', data);
        setIsSuccess(true);
        setMessage('Registration successful! You can now log in.');
      } else {
        setMessage('Signup failed.');
      }
    } catch (error) {
      console.error('Error:', error);
      setMessage('An error occurred. Please try again.');
    }
  };

  return (
    <div style={{ marginTop: '50px', marginBottom: '100px' }}>
      <Container className="mt-5 p-4">
        <Row className="justify-content-center">
          <Col md="6" lg="4">
            {isSuccess && (
              <Alert variant="success" onClose={() => setIsSuccess(false)} dismissible>
                {message}
              </Alert>
            )}
            <form onSubmit={handleSubmit} className="border p-4 bg-dark text-white">
              <h2 className="text-white">Create your account</h2>

              <Form.Group>
                <Form.Label>First Name:</Form.Label>
                <input
                  type="text"
                  name="firstName"
                  placeholder="Enter your first name"
                  className="form-control"
                  value={formData.firstName}
                  onChange={handleChange}
                  required
                />
              </Form.Group>

              <Form.Group>
                <Form.Label>Last Name:</Form.Label>
                <input
                  type="text"
                  name="lastName"
                  placeholder="Enter your last name"
                  className="form-control"
                  value={formData.lastName}
                  onChange={handleChange}
                  required
                />
              </Form.Group>

              <Form.Group>
                <Form.Label>Email:</Form.Label>
                <input
                  type="email"
                  name="email"
                  placeholder="Enter your email"
                  className="form-control"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />
              </Form.Group>

              <Form.Group>
                <Form.Label>Password:</Form.Label>
                <input
                  type="password"
                  name="password"
                  placeholder="Enter your password"
                  className="form-control"
                  value={formData.password}
                  onChange={handleChange}
                  required
                />
              </Form.Group>

              <br />
              <Button variant="success" type="submit" className="w-100">
                Sign Up
              </Button>

              <div className="text-center">
                <p style={{ color: '#cccccc' }}>Already Have an Account?</p>
                <Link to="/login" className="btn btn-light">
                  Login Here
                </Link>
              </div>
            </form>
          </Col>
        </Row>
      </Container>
    </div>
  );
}

export default SignUp;
