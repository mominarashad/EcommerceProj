import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom'; // Import useNavigate for navigation

const CartPage = () => {
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Get user_id from localStorage (for the logged-in user)
  const user_id = localStorage.getItem('user_id');
  const navigate = useNavigate(); // Initialize useNavigate

  useEffect(() => {
    if (!user_id) {
      // If there's no user_id in localStorage, redirect to login page (optional)
      window.location.href = '/login';
      return;
    }

    // Fetch cart items from the backend for the logged-in user
    axios
      .get(`http://localhost:5000/api/cart/${user_id}`)
      .then((response) => {
        setCartItems(response.data);
        setLoading(false);
      })
      .catch((err) => {
        console.error('Error fetching cart:', err);
        setError('Error fetching cart items');
        setLoading(false);
      });
  }, [user_id]);

  const handleQuantityChange = (cart_id, newQuantity) => {
    if (newQuantity < 1) return; // Prevent reducing quantity below 1

    console.log('Updating cart item:', cart_id, 'to new quantity:', newQuantity); // Log the data

    // Update the quantity in the backend
    axios
      .put(`http://localhost:5000/api/cart/update/${cart_id}`, { quantity: newQuantity })
      .then((response) => {
        console.log('Quantity updated successfully:', response.data);

        // Update the local state with the new quantity
        setCartItems((prevItems) =>
          prevItems.map((item) =>
            item.cart_id === cart_id ? { ...item, quantity: newQuantity } : item
          )
        );
      })
      .catch((err) => {
        console.error('Error updating quantity:', err);
      });
  };

  // Remove an item from the cart
  const handleRemoveItem = (cart_id) => {
    axios
      .delete(`http://localhost:5000/api/cart/remove/${cart_id}`)
      .then((response) => {
        console.log('Item removed from cart:', response.data);

        // Remove the item from the local state
        setCartItems((prevItems) =>
          prevItems.filter((item) => item.cart_id !== cart_id)
        );
      })
      .catch((err) => {
        console.error('Error removing item:', err);
      });
  };

  // Handle navigating to the checkout page
  const handleProceedToCheckout = () => {
    navigate('/checkout'); // Navigate to the checkout page
  };

  if (loading) return <p>Loading cart...</p>;
  if (error) return <p>{error}</p>;

  return (
    <div className="cart-page">
      <h2>Your Cart</h2>

      <div className="cart-items">
        {cartItems.map((item) => (
          <div className="cart-item" key={item.cart_id}>
            <img
              src={item.image_path}
              alt={item.name}
              style={{ width: '100px', height: '100px', objectFit: 'cover' }}
            />
            <div className="product-details">
              <h3>{item.name}</h3>
              <p>{item.description}</p>
              <p>Price: ${item.price}</p>

              <div className="quantity-selector">
                <button
                  onClick={() => handleQuantityChange(item.cart_id, item.quantity - 1)}
                  disabled={item.quantity <= 1}
                >
                  -
                </button>
                <span>{item.quantity}</span>
                <button onClick={() => handleQuantityChange(item.cart_id, item.quantity + 1)}>
                  +
                </button>
              </div>
              <button
                onClick={() => handleRemoveItem(item.cart_id)}
                style={{ backgroundColor: 'red', color: 'white', padding: '5px 10px', marginTop: '10px' }}
              >
                Remove from Cart
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="cart-summary">
        <button
          onClick={handleProceedToCheckout}
          style={{ backgroundColor: 'green', color: 'white', padding: '10px 20px', marginTop: '20px' }}
        >
          Proceed to Checkout
        </button>
      </div>
    </div>
  );
};

export default CartPage;
