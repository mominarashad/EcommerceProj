import React, { useState } from "react";
import axios from "axios";
import "../styles/Settings.css"; // Add your custom styles

const Settings = () => {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    gender: "",
    dateOfBirth: "",
    address: "",
    contact: "",
    cnic: "",
    officeEmail: "",
    city: "",
    state: "",
    country: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSave = async () => {
    try {
      const response = await axios.post("http://localhost:5000/save-settings", formData);
      alert(response.data.message || "Changes saved successfully!");
    } catch (error) {
      console.error("Error saving data:", error);
      alert("Failed to save changes. Please try again.");
    }
  };

  const handleDelete = async () => {
    try {
      const response = await axios.delete("http://localhost:5000/save-settings", {
        data: { email: formData.email }, // Assuming deletion is based on email
      });
      alert(response.data.message || "Account deleted successfully!");
    } catch (error) {
      console.error("Error deleting account:", error);
      alert("Failed to delete account. Please try again.");
    }
  };

  return (
    <div className="settings-container">
      <h2>Settings</h2>
      <form>
        {/* First Name */}
        <div className="form-row">
          <label>First Name</label>
          <input
            type="text"
            name="firstName"
            value={formData.firstName}
            onChange={handleChange}
            placeholder="Enter First Name"
          />
        </div>

        {/* Last Name */}
        <div className="form-row">
          <label>Last Name</label>
          <input
            type="text"
            name="lastName"
            value={formData.lastName}
            onChange={handleChange}
            placeholder="Enter Last Name"
          />
        </div>

        {/* Email */}
        <div className="form-row">
          <label>Email</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="Enter Email"
          />
        </div>

        {/* Gender */}
        <div className="form-row">
          <label>Gender</label>
          <div>
            <label>
              <input
                type="radio"
                name="gender"
                value="Male"
                checked={formData.gender === "Male"}
                onChange={handleChange}
              />
              Male
            </label>
            <label style={{ marginLeft: "20px" }}>
              <input
                type="radio"
                name="gender"
                value="Female"
                checked={formData.gender === "Female"}
                onChange={handleChange}
              />
              Female
            </label>
          </div>
        </div>

        {/* Date of Birth */}
        <div className="form-row">
          <label>Date of Birth</label>
          <input
            type="date"
            name="dateOfBirth"
            value={formData.dateOfBirth}
            onChange={handleChange}
          />
        </div>

        {/* Address */}
        <div className="form-row">
          <label>Address</label>
          <input
            type="text"
            name="address"
            value={formData.address}
            onChange={handleChange}
            placeholder="Enter Address"
          />
        </div>

        {/* Contact */}
        <div className="form-row">
          <label>Contact</label>
          <input
            type="text"
            name="contact"
            value={formData.contact}
            onChange={handleChange}
            placeholder="Enter Contact Number"
          />
        </div>

        {/* CNIC */}
        <div className="form-row">
          <label>CNIC</label>
          <input
            type="text"
            name="cnic"
            value={formData.cnic}
            onChange={handleChange}
            placeholder="Enter CNIC"
          />
        </div>

        {/* Office Email */}
        <div className="form-row">
          <label>Office Email</label>
          <input
            type="email"
            name="officeEmail"
            value={formData.officeEmail}
            onChange={handleChange}
            placeholder="Enter Office Email"
          />
        </div>

        {/* City */}
        <div className="form-row">
          <label>City</label>
          <input
            type="text"
            name="city"
            value={formData.city}
            onChange={handleChange}
            placeholder="Enter City"
          />
        </div>

        {/* State */}
        <div className="form-row">
          <label>State</label>
          <input
            type="text"
            name="state"
            value={formData.state}
            onChange={handleChange}
            placeholder="Enter State"
          />
        </div>

        {/* Country */}
        <div className="form-row">
          <label>Country</label>
          <input
            type="text"
            name="country"
            value={formData.country}
            onChange={handleChange}
            placeholder="Enter Country"
          />
        </div>
      </form>

      <div className="form-actions">
        <button type="button" className="delete-button" onClick={handleDelete}>
          Delete Account
        </button>
        <button type="button" className="save-button" onClick={handleSave}>
          Save Changes
        </button>
      </div>
    </div>
  );
};

export default Settings;
