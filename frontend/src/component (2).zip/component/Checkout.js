import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Checkout = () => {
  const [userId, setUserId] = useState(null);
  const [formData, setFormData] = useState({
    firstname: '',
    lastname: '',
    email: '',
    city: '',
    postalCode: '',
    phoneNumber: '',
    address: ''
  });

  const [totalCost, setTotalCost] = useState(0); // To store total cost

  useEffect(() => {
    // Get the user ID from localStorage (ensure the user is logged in)
    const storedUserId = localStorage.getItem('user_id');
    if (storedUserId) {
      setUserId(storedUserId);
      fetchCartTotal(storedUserId); // Fetch cart total on load
    } else {
      // Handle case where the user is not logged in
      console.log('User is not logged in');
    }
  }, []);

  const fetchCartTotal = async (userId) => {
    try {
      const response = await axios.get(`http://localhost:5000/cart/total/${userId}`);
      setTotalCost(response.data.totalCost); // Set total cost from response
    } catch (error) {
      console.error('Error fetching cart total:', error.response ? error.response.data : error.message);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Ensure user ID is present
    if (!userId) {
      console.log('User ID is required');
      return;
    }

    try {
      // Send the form data and userId to the backend
      const response = await axios.post('http://localhost:5000/checkout', {
        userId,
        ...formData,
        totalCost
      });

      // Handle success (e.g., redirect to a success page or display message)
      console.log('Checkout successful', response.data);
    } catch (error) {
      console.error('Error during checkout:', error.response ? error.response.data : error.message);
    }
  };

  return (
    <div>
      <h2>Checkout</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>First Name:</label>
          <input
            type="text"
            name="firstname"
            value={formData.firstname}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>Last Name:</label>
          <input
            type="text"
            name="lastname"
            value={formData.lastname}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>Email:</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>City:</label>
          <input
            type="text"
            name="city"
            value={formData.city}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>Postal Code:</label>
          <input
            type="text"
            name="postalCode"
            value={formData.postalCode}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>Phone Number:</label>
          <input
            type="text"
            name="phoneNumber"
            value={formData.phoneNumber}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>Address:</label>
          <input
            type="text"
            name="address"
            value={formData.address}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label>Total Cost: ${totalCost}</label>
        </div>
        <button type="submit">Complete Checkout</button>
      </form>
    </div>
  );
};

export default Checkout;
