import React, { useEffect, useState } from "react";
import axios from "axios";
import ProductCard from "./ProductCard";

const KababjeesPage = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filter, setFilter] = useState(""); // Store the selected filter option

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/foods/KFC") // Backend route for Kababjees
      .then((response) => {
        setProducts(response.data);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Error fetching Kababjees products:", err);
        setError("Error fetching Kababjees products");
        setLoading(false);
      });
  }, []);

  // Add to Cart Functionality
  const handleAddToCart = async (product_id) => {
    const user_id = localStorage.getItem("user_id"); // Retrieve user ID from localStorage

    if (!user_id) {
      alert("Please log in to add products to your cart.");
      return;
    }

    try {
      const response = await axios.post("http://localhost:5000/api/cart", {
        user_id,
        product_id,
        quantity: 1, // Default quantity to 1
      });
      alert(response.data.message || "Product added to cart successfully!");
    } catch (err) {
      console.error("Error adding product to cart:", err);
      alert("Failed to add product to cart. Please try again.");
    }
  };

  // Function to handle sorting
  const handleSort = (sortBy) => {
    let sortedProducts = [...products];

    if (sortBy === "price-high-to-low") {
      sortedProducts.sort((a, b) => b.price - a.price);
    } else if (sortBy === "price-low-to-high") {
      sortedProducts.sort((a, b) => a.price - b.price);
    } else if (sortBy === "A-to-Z") {
      sortedProducts.sort((a, b) => a.name.localeCompare(b.name));
    } else if (sortBy === "Z-to-A") {
      sortedProducts.sort((a, b) => b.name.localeCompare(a.name));
    }

    setProducts(sortedProducts);
  };

  // Function to handle filter change
  const handleFilterChange = (e) => {
    setFilter(e.target.value);
    handleSort(e.target.value);
  };

  if (loading) return <p>Loading...</p>;
  if (error) return <p>{error}</p>;

  return (
    <div>
      <div>
        <label htmlFor="filter">Sort By: </label>
        <select id="filter" value={filter} onChange={handleFilterChange}>
          <option value="">Select</option>
          <option value="price-high-to-low">Price: High to Low</option>
          <option value="price-low-to-high">Price: Low to High</option>
          <option value="A-to-Z">Name: A to Z</option>
          <option value="Z-to-A">Name: Z to A</option>
        </select>
      </div>

      <div className="product-list" style={{ display: "flex", flexWrap: "wrap", gap: "16px" }}>
        {products.map((product) => (
          <ProductCard key={product.product_id} product={product} onAddToCart={handleAddToCart} />
        ))}
      </div>
    </div>
  );
};

export default KababjeesPage;
